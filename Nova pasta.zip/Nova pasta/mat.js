//Adição com Drag & Drop
const items = document.querySelectorAll('.resultado p span');
const dropZone = document.querySelector('#resposta');

const dropZoneContainer = document.querySelector('.resposta');

function onDragStart(evento){
    // console.log('Evento iniciado');
    setTimeout(function() {
    evento.target.classList.add('move');
    }, 1);
}

function onDragEnter(){
    dropZone.classList.add('enter');
}

function onDragEnd(evento){
    dropZone.classList.remove('enter');
    dropZone.classList.add('dropped');
    // console.log('Evento encerrado');

    const valor = evento.target.textContent
    dropZone.textContent = valor;

    if (2 + 2 === parseInt(valor)) {
        // console.log('Acertou');
        // document.querySelector('.resposta').classList.add('correct');

        // dropZone.classList.remove('error');
        // dropZone.classList.add('correct');

        dropZoneContainer.classList.remove('error');
        dropZoneContainer.classList.add('correct');
    }else{
        // console.log('Errou');
        // document.querySelector('.resposta').classList.add('error');

        // dropZone.classList.remove('correct');
        // dropZone.classList.add('error');

        dropZoneContainer.classList.remove('correct');
        dropZoneContainer.classList.add('error');
    }
}

function onDragLeave(){
    dropZone.classList.remove('enter');
}
//Add eventos
dropZone.addEventListener('dragenter', onDragEnter);
dropZone.addEventListener('dragleave', onDragLeave);

items.forEach(function(item){
    item.addEventListener('dragstart', onDragStart);
    item.addEventListener('dragend', onDragEnd);
});

document.querySelector('.recomAdicao').addEventListener('click', function() {window.location.reload();});