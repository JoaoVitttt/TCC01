const arrastarjogo3 = document.querySelectorAll(".draggable");
const soltarjogo3 = document.querySelectorAll(".dropzone");

arrastarjogo3.forEach(elem => {
  elem.addEventListener("dragstart", dragStart);
});

soltarjogo3.forEach(elem => {
  elem.addEventListener("dragenter", dragEnter); 
  elem.addEventListener("dragover", dragOver);
  elem.addEventListener("dragleave", dragLeave);
  elem.addEventListener("soltar", soltar);
});


function dragStart(event) {
  event.dataTransfer.setData("text", event.target.id);
}


function dragEnter(event) {
  if(!event.target.classList.contains("dropzone")) {
    event.target.classList.add("dropzone-hover");
  }
}

function dragOver(event) {
  if(!event.target.classList.contains("dropzone")) {
    event.preventDefault(); 
}

function dragLeave(event) {
  if(!event.target.classList.contains("dropzone")) {
    event.target.classList.remove("dropzone-hover");
  }
}

function drop(event) {
  event.preventDefault();
  event.target.classList.remove("dropzone-hover");
  const arrastarjogo3 = event.dataTransfer.getData("text"); 
  const soltarjogo3Data = event.target.getAttribute("data-draggable-id");
  const isCorrectMatching = arrastarjogo3 === soltarjogo3Data;
  if(isCorrectMatching) {
    const arrastarjogo3 = document.getElementById(arrastarjogo3);
    event.target.classList.add("dropzone");

    event.target.style.backgroundColor = window.getComputedStyle(arrastarjogo3).color;
    arrastarjogo3.classList.add("dragged");
    arrastarjogo3.setAttribute("draggable", "false");
  }
}}