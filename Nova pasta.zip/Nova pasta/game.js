//Jogo da Memória
const game = document.querySelector('.game');

const imagens = [
    'asfgg',
    'asfgg',
    'asfgg',
    'asfgg',
    'asfgg'
];

const createElement = (tag, className) => {
    const element = document.createElement(tag);
    element.className = className;
    return element;
}
const criarGame = () => {
    const carta = createElement('div', 'fv');
    const frente = createElement('div', 'frente');
    const verso = createElement('div', 'verso');

    carta.appendChild(frente);
    carta.appendChild(verso);

    return carta;
}

const loadGame = () => {
    imagens.forEach((image) => {
        const carta = criarGame();
        game.appendChild(carta);
    });
}
loadGame();